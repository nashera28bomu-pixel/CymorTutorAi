const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    educationLevel: {
      type: String,
      enum: ['Lower Primary', 'Upper Primary', 'Junior School', 'Senior School', null],
      default: null
    },
    subjects: [{ type: String }],
    onboardingComplete: { type: Boolean, default: false },
    role: { type: String, enum: ['student', 'admin'], default: 'student' }
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
